package byteAbout;

public class exhange {
    public static void main(String[] args) {
        System.out.println(byteAsciiToChar(104));
    }

    public static char byteAsciiToChar(int ascii){
        char ch = (char)ascii;
        return ch;
    }
}
